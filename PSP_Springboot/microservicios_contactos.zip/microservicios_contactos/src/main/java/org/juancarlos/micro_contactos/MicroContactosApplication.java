package org.juancarlos.micro_contactos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroContactosApplication {

    public static void main(String[] args) {
        SpringApplication.run(MicroContactosApplication.class, args);
    }

}
