package org.juancarlos.micro_contactos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroContactosApplicationTests {

    @Test
    void contextLoads() {
    }

}
